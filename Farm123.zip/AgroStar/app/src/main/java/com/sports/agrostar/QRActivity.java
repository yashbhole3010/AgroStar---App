package com.sports.agrostar;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

public class QRActivity extends AppCompatActivity {

    private static final int QR_CODE_DIMENSION = 300;

    ImageView QRcode;
    Bitmap bitmap;
    SharedPreferences preferences;
    String strUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qractivity);

        preferences = PreferenceManager.getDefaultSharedPreferences(QRActivity.this);
        strUsername = preferences.getString("username", "");

        QRcode = findViewById(R.id.ivQRCodeQR);

        try {
            createQRCode();
        } catch (WriterException e) {
            Toast.makeText(QRActivity.this, "Error generating QR code: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void createQRCode() throws WriterException {
        if (strUsername == null || strUsername.isEmpty()) {
            Toast.makeText(QRActivity.this, "Username is empty or null", Toast.LENGTH_SHORT).show();
            return;
        }

        bitmap = textToImageEncode(strUsername);
        if (bitmap != null) {
            QRcode.setImageBitmap(bitmap);
        } else {
            Toast.makeText(QRActivity.this, "Failed to generate QR code", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap textToImageEncode(String strUsername) throws WriterException {
        BitMatrix bitMatrix = new MultiFormatWriter().encode(strUsername, BarcodeFormat.QR_CODE, QR_CODE_DIMENSION, QR_CODE_DIMENSION);
        int width = bitMatrix.getWidth();
        int height = bitMatrix.getHeight();
        int[] pixels = new int[width * height];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                pixels[y * width + x] = bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE;
            }
        }

        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.RGB_565);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up bitmap resources if needed
        if (bitmap != null) {
            bitmap.recycle();
            bitmap = null;
        }
    }
}
