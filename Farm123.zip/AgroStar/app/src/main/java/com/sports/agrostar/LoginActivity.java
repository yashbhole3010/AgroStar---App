package com.sports.agrostar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceManager;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    EditText etusername,etpass;
    CheckBox cbloginshowhidepass;
    Button btnlogin;
    TextView tvnew;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preferences = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
        editor= preferences.edit();

        if (preferences.getBoolean("isLogin",false))
        {
            Intent i = new Intent(LoginActivity.this,HomeActivity.class);
            startActivity(i);
        }

        etusername=findViewById(R.id.etlgnusername);
        etpass=findViewById(R.id.etloginpass);
        cbloginshowhidepass=findViewById(R.id.cbloginshowpass);
        btnlogin=findViewById(R.id.btnloginlogin);
        tvnew=findViewById(R.id.tvnewuser);

        cbloginshowhidepass.setOnCheckedChangeListener(new  CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView ,boolean isChecked){

                if(isChecked)
                {
                    etpass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else
                {
                    etpass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etusername.getText().toString().isEmpty()) {
                    etusername.setError("Please enter your username");
                } else if (etpass.getText().toString().isEmpty()) {
                    etpass.setError("PleaSE enter your password");
                } else if (etusername.getText().toString().length() < 8) {
                    etusername.setError("Enter 8 character username");
                } else if (etpass.getText().toString().length() < 8) {
                    etpass.setError("Please enter 8 character password");
                } else if (!etusername.getText().toString().matches(".*[A-Z].*"))
                {
                    etusername.setError("use 1 Uppercase letter");
                } else if (!etusername.getText().toString().matches(".*[a-z].*"))
                {
                    etusername.setError("use 1 Lowercase letter");
                } else if (!etusername.getText().toString().matches(".*[0-9].*"))
                {
                    etusername.setError("use 1 Number");
                } else if (!etusername.getText().toString().matches(".*[@,#,$].*"))
                {
                    etusername.setError("use 1 one special symbol");
                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Login Successfully done!!", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginActivity.this,HomeActivity.class);
                    editor.putString("username",etusername.getText().toString()).commit();
                    editor.putBoolean("isLogin",true).commit();
                    startActivity(i);
                }
            }
        });
       tvnew.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(LoginActivity.this,RegistrationActivity.class);
               startActivity(intent);
           }
       });
    }
}