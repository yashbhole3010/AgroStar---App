package com.sports.agrostar;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegistrationActivity extends AppCompatActivity {

    EditText etrgstrname,etmobileno,etemailid,etusernm,etpassword;
    CheckBox cbshowhidepass;
    Button btnregister;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        preferences= PreferenceManager.getDefaultSharedPreferences(RegistrationActivity.this);
        editor= preferences.edit();

        etrgstrname=findViewById(R.id.etname);
        etmobileno=findViewById(R.id.etmonumber);
        etemailid=findViewById(R.id.etemail);
        etusernm=findViewById(R.id.etusername);
        etpassword=findViewById(R.id.etmpass);
        cbshowhidepass=findViewById(R.id.cbreshowpass);
        btnregister=findViewById(R.id.btnrgstr);


        cbshowhidepass.setOnCheckedChangeListener(new  CompoundButton.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView ,boolean isChecked)
            {
                if(isChecked)
                {
                    etpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else
                {
                    etpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        btnregister.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                if (etrgstrname.getText().toString().isEmpty() ||etrgstrname.getText().toString().length() <8 ){
                    etrgstrname.setError("Please enter your name");
                } else if (etmobileno.getText().toString().isEmpty()||etmobileno.getText().toString().length() <9 ) {
                    etmobileno.setError("Please enter your Number");
                }else if (etemailid.getText().toString().isEmpty()) {
                    etemailid.setError("Please enter your E-mailid");
                } else if (etpassword.getText().toString().length()<8) {
                    etpassword.setError("Please enter 8 character long password");
                }else if (!etusernm.getText().toString().matches(".*[A-Z].*"))
                {
                    etusernm.setError("use 1 Uppercase letter");
                } else if (!etusernm.getText().toString().matches(".*[a-z].*"))
                {
                    etusernm.setError("use 1 Lowercase letter");
                } else if (!etusernm.getText().toString().matches(".*[0-9].*"))
                {
                    etusernm.setError("use 1 Number");
                } else if (!etusernm.getText().toString().matches(".*[@,#,$].*"))
                {
                    etusernm.setError("use 1 one special symbol");
                }
                else
                {
                    Intent i =new Intent(RegistrationActivity.this,LoginActivity.class);
                    editor.putString("Name",etrgstrname.getText().toString()).commit();
                    editor.putString("Mobile No",etmobileno.getText().toString()).commit();
                    editor.putString("EmailId",etemailid.getText().toString()).commit();
                    editor.putString("Username",etusernm.getText().toString()).commit();
                    editor.putString("Password",etpassword.getText().toString()).commit();
                    Toast.makeText(RegistrationActivity.this, "Register Successfully done!!", Toast.LENGTH_SHORT).show();
                    startActivity(i);
                }
            }
        });
    }
}