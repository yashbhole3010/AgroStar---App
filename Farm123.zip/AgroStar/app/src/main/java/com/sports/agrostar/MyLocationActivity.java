package com.sports.agrostar;

import androidx.fragment.app.FragmentActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.sports.agrostar.databinding.ActivityMyLocation2Binding;

public class MyLocationActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMyLocation2Binding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMyLocation2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add markers with custom icons and titles
        LatLng mountreachsolution = new LatLng(20.899311155238976, 77.76389196864615);
        LatLng arvicollege = new LatLng(20.995325661353778, 78.20572716864893);

        // Example of custom marker with an image
        Bitmap markerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.cologe);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(markerBitmap, 50, 50, false);

        mMap.addMarker(new MarkerOptions()
                .position(mountreachsolution)
                .title("Marker in Mountreach Solution pv.ltd")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.mountreachlyd)));

        mMap.addMarker(new MarkerOptions()
                .position(arvicollege)
                .title("Marker in GP Arvi")
                .icon(BitmapDescriptorFactory.fromBitmap(resizedBitmap)));

        // Move camera to a default position (you can adjust this based on your needs)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(mountreachsolution, 12));

        // Example of adding a circle around a marker
        mMap.addCircle(new CircleOptions()
                .center(mountreachsolution)
                .radius(150)
                .strokeColor(Color.parseColor("#06A8F1"))
                .fillColor(Color.parseColor("#8706A8F1"))); // Adjust fill color with opacity

        // Example of adding a polyline between markers
        mMap.addPolyline(new PolylineOptions()
                .add(mountreachsolution, arvicollege)
                .color(Color.GREEN)
                .width(5));
    }
}
