package com.sports.agrostar;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MyProfileActivity extends AppCompatActivity {

    ImageView ivProfilePhoto;
    Button btnChangeProfilePhoto;
    TextView tvName,tvMobileno,tvEmailid,tvUsername,tvPassword;

    TextView  tvtoken;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    Uri filefileImagePath;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_my_profile);

        preferences = PreferenceManager.getDefaultSharedPreferences(MyProfileActivity.this);
        editor= preferences.edit();

        Toast.makeText(MyProfileActivity.this, "My Profile open", Toast.LENGTH_SHORT).show();


        ivProfilePhoto=findViewById(R.id.ivprofilePhoto);
        btnChangeProfilePhoto=findViewById(R.id.btnmyprofilechangeprofilephoto);
        tvName=findViewById(R.id.MyProfileName);
        tvMobileno=findViewById(R.id.MyProfileNumber);
        tvEmailid=findViewById(R.id.MyProfileEmail_id);
        tvUsername=findViewById(R.id.MyProfileUserName);
        tvPassword=findViewById(R.id.MyProfilePassword);
        tvtoken=findViewById(R.id.tvmyprofileToken);

        String strName = preferences.getString("Name","");
        tvName.setText(strName);

        String strMobileNo = preferences.getString("Mobile No","");
        tvMobileno.setText(strMobileNo);

        String strEmailId = preferences.getString("EmailId","");
        tvEmailid.setText(strEmailId);

        String strUsername = preferences.getString("UserName","");
        tvUsername.setText(strUsername);

        String strPassword = preferences.getString("Password","");
        tvPassword.setText(strPassword);

        File imageFile = new File(getFilesDir(),"profile.png");
        if (imageFile.exists())
        {
            Bitmap savedBitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
            ivProfilePhoto.setImageBitmap(savedBitmap);

        }


        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Toast.makeText(MyProfileActivity.this,"FCM Token  not Received",Toast.LENGTH_LONG).show();
                            return;
                        }
                        // Get new FCM registration token
                        String token = task.getResult();
                        tvtoken.setText(token);
                        Toast.makeText(MyProfileActivity.this, token, Toast.LENGTH_SHORT).show();
                    }
                });

        btnChangeProfilePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showImageChooser();
            }

            private void showImageChooser() {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i,"Select profiele photo"),999);
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(MyProfileActivity.this,LoginActivity.class);
        startActivity(i);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 999 && resultCode == RESULT_OK && data!=null)
        {

            filefileImagePath=  data.getData();

           try {
               bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),filefileImagePath);
               ivProfilePhoto.setImageBitmap(bitmap);

               File imageFile = new File(getFilesDir(),"profile.png");
               FileOutputStream outputStream  = openFileOutput(imageFile.getName(), Context.MODE_PRIVATE);
               bitmap.compress(Bitmap.CompressFormat.JPEG,100,outputStream);

           }catch (IOException  e)
           {
               throw new RuntimeException(e);
           }
        }

    }
}