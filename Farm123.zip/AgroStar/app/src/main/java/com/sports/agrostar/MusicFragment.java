package com.sports.agrostar;

import android.media.MediaPlayer;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


public class MusicFragment extends Fragment {

    TextView  tvsongname,tvStartTime,tvTotalTime;
    ImageView SongImage;
    SeekBar songProgress;
    ImageView ivPrevious,ivBackward,ivPlay,ivForward,ivNext;

    private  int currentIndex = 0;
    MediaPlayer mediaPlayer;
    
    private static int sTime = 0,tTime = 0,oTime = 0,bTime = 5000,fTime = 5000;
    Handler handler = new Handler();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.music_fragment, container, false);

        tvsongname=view.findViewById(R.id.tvplayingsong);
        tvStartTime=view.findViewById(R.id.tvstarttime);
        tvTotalTime=view.findViewById(R.id.tvtotaltime);
        SongImage=view.findViewById(R.id.ivsonglogo);
        songProgress=view.findViewById(R.id.songprogress);
        ivPrevious=view.findViewById(R.id.ivprevious);
        ivBackward=view.findViewById(R.id.ivbackward);
        ivPlay=view.findViewById(R.id.ivplay);
        ivForward=view.findViewById(R.id.ivforward);
        ivNext=view.findViewById(R.id.ivnext);

        ArrayList<Integer> songArrayList = new ArrayList<>();
        songArrayList.add(0,R.raw.cheques);
        songArrayList.add(1,R.raw.soulmate);
        songArrayList.add(2,R.raw.kahani_suno);


        mediaPlayer = MediaPlayer.create(getActivity(),songArrayList.get(currentIndex));

        ivPlay.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                if (mediaPlayer!=null&&mediaPlayer.isPlaying())
                {
                    mediaPlayer.pause();
                    ivPlay.setImageResource(R.drawable.icon_play);
                }
                else
                {
                    mediaPlayer.start();
                    ivPlay.setImageResource(R.drawable.icon_pause);
                }

                tTime=mediaPlayer.getDuration();
                sTime=mediaPlayer.getCurrentPosition();

                if (oTime==0)
                {
                    songProgress.setMax(tTime);
                    oTime=1;

                }

                tvTotalTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(tTime),
                        TimeUnit.MILLISECONDS.toSeconds(tTime)-
                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(tTime))));

                tvStartTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(sTime),
                        TimeUnit.MILLISECONDS.toSeconds(sTime)-
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(sTime))));

                handler.postDelayed(UpdateSongProgess,1000);
                songDetails();
            }
        });

        songProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                if (fromUser)
                {
                    mediaPlayer.seekTo(progress);
                    songProgress.setProgress(progress);

                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        ivPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex > 0)
                {
                    currentIndex--;
                }
                else {

                    currentIndex= songArrayList.size() -1 ;
                }

                if (mediaPlayer.isPlaying())
                {
                    mediaPlayer.stop();
                }
                if (mediaPlayer!=null)
                {
                    ivPlay.setImageResource(R.drawable.icon_pause);

                }

                mediaPlayer= mediaPlayer.create(getActivity(),songArrayList.get(currentIndex));
                tTime=mediaPlayer.getDuration();
                sTime=mediaPlayer.getCurrentPosition();

                oTime=0;
                if (oTime==0)
                {
                    songProgress.setMax(tTime);
                    oTime=1;

                }

                tvTotalTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(tTime),
                        TimeUnit.MILLISECONDS.toSeconds(tTime)-
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(tTime))));

                tvStartTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(sTime),
                        TimeUnit.MILLISECONDS.toSeconds(sTime)-
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(sTime))));

                handler.postDelayed(UpdateSongProgess,1000);
                mediaPlayer.start();
                songDetails();
            }
        });

        ivBackward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((sTime-bTime)>0)
                {
                    sTime = sTime-bTime;
                    mediaPlayer.seekTo(sTime);
                }
                else {
                    Toast.makeText(getActivity(),"cant jump Backward for 5 second",Toast.LENGTH_LONG).show();
                }
            }
        });

        ivForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((sTime+fTime)<tTime)
                {
                    sTime = sTime+fTime;
                    mediaPlayer.seekTo(sTime);
                }
                else {
                    Toast.makeText(getActivity(),"cannot jump Backward for 5 second",Toast.LENGTH_LONG).show();
                }
            }
        });


        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentIndex < songArrayList.size()-1)
                {
                    currentIndex++;
                }
                else {

                    currentIndex= 0 ;
                }

                if (mediaPlayer.isPlaying())
                {
                    mediaPlayer.stop();
                }
                if (mediaPlayer!=null)
                {
                    ivPlay.setImageResource(R.drawable.icon_pause);

                }

                mediaPlayer= mediaPlayer.create(getActivity(),songArrayList.get(currentIndex));
                tTime=mediaPlayer.getDuration();
                sTime=mediaPlayer.getCurrentPosition();

                oTime=0;
                if (oTime == 0)
                {
                    songProgress.setMax(tTime);
                    oTime=1;

                }

                tvTotalTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(tTime),
                        TimeUnit.MILLISECONDS.toSeconds(tTime)-
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(tTime))));

                tvStartTime.setText(String.format("%d:%d ",
                        TimeUnit.MILLISECONDS.toMinutes(sTime),
                        TimeUnit.MILLISECONDS.toSeconds(sTime)-
                                TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(sTime))));

                handler.postDelayed(UpdateSongProgess,1000);
                mediaPlayer.start();
                songDetails();
            }
        });
        return view;
    }

    private void songDetails() {

        if (currentIndex == 0)
        {
            tvsongname.setText("cheques");
            SongImage.setImageResource(R.drawable.chequesss);
        } else if (currentIndex == 1) {
            tvsongname.setText("Soulmate");
            SongImage.setImageResource(R.drawable.soulmat);
        } else if (currentIndex == 2) {
            tvsongname.setText("kahani_suno");
            SongImage.setImageResource(R.drawable.kahani_suno);
        }
    }

    private Runnable UpdateSongProgess = new Runnable() {
        @Override
        public void run() {

            sTime = mediaPlayer.getCurrentPosition();

            tvStartTime.setText(String.format("%d:%d",
                    TimeUnit.MILLISECONDS.toMinutes(sTime),
                    TimeUnit.MILLISECONDS.toSeconds(sTime)-
                    TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(sTime))));

            songProgress.setProgress(sTime);

            handler.postDelayed(this,1000);
        }
    };
}