package com.sports.agrostar;

import android.os.Bundle;
import android.content.Intent;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.os.Handler;
import android.view.animation.AnimationUtils;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.TextView;

public class splash_Activity extends AppCompatActivity {

    ImageView ivlogo;
    TextView tvtitle;
    Animation fadeinanim;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.splashactivity);

        ivlogo = findViewById(R.id.ivlogo);
        tvtitle =findViewById(R.id.tvTitle);

        fadeinanim= AnimationUtils.loadAnimation(splash_Activity.this,R.anim.fadein);
        ivlogo.setAnimation(fadeinanim);
        tvtitle.setAnimation(fadeinanim);


        Handler handler= new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(splash_Activity.this,LoginActivity.class);
                startActivity(i);
            }
        },3000);
    }
}
