package com.sports.agrostar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;

import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.denzcoskun.imageslider.interfaces.ItemClickListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;

public class HomeFragment extends Fragment {
    ImageSlider imageSlider;
    ImageView ivmic;
    SearchView etSearch;
    ListView listView;
    ArrayAdapter<String> adapter;

    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    TextToSpeech textToSpeech;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        imageSlider = view.findViewById(R.id.issHomeImageSlider);
        ivmic = view.findViewById(R.id.icon_mic);
        etSearch = view.findViewById(R.id.etsearch);
        listView = view.findViewById(R.id.lv);

        String[] name = {"Tarplus Sheet 24*20 (Tadpatri) Yellow Lemon", "Gladiator Plus Double Motor Pump GL1012", "Power Gel (Organic Plant Nutrient) 500 g"};
        Integer[] img = {R.drawable.tarplussheet, R.drawable.double_motor_pump, R.drawable.plant_nutrient};

        adapter = new MyListAdapter(getActivity(), name, img);
        listView.setAdapter(adapter);
        listView.setTextFilterEnabled(true);
        listView.setVisibility(View.GONE); // Initially hide the list view

        etSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if (!query.isEmpty()) {
                    adapter.getFilter().filter(query);
                    listView.setVisibility(View.VISIBLE);
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                if (!s.isEmpty()) {
                    adapter.getFilter().filter(s);
                    listView.setVisibility(View.VISIBLE);
                } else {
                    listView.setVisibility(View.GONE);
                }
                return false;
            }
        });

        ivmic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak Now");

                try {
                    startActivityForResult(i, REQUEST_CODE_SPEECH_INPUT);
                } catch (Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        ArrayList<SlideModel> slideModelArrayList = new ArrayList<>();
        slideModelArrayList.add(new SlideModel(R.drawable.agrostarcompany, ScaleTypes.CENTER_CROP));
        slideModelArrayList.add(new SlideModel("https://4.imimg.com/data4/TA/XH/ANDROID-24937924/product-250x250.jpeg", ScaleTypes.CENTER_CROP));
        slideModelArrayList.add(new SlideModel("https://pbs.twimg.com/media/E8pxwNXVEAAJVDl.jpg:large", ScaleTypes.CENTER_CROP));
        slideModelArrayList.add(new SlideModel("https://www.shutterstock.com/image-photo/contact-us-customer-support-hotline-600nw-2067737414.jpg", ScaleTypes.CENTER_CROP));
        imageSlider.setImageList(slideModelArrayList);

        imageSlider.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemSelected(int position) {
                switch (position) {
                    case 3:
                        // Navigate to SpecificActivity1
                        Intent i = new Intent(getActivity(), ContactusActivity.class);
                        startActivity(i);
                        break;
                }
            }

            @Override
            public void doubleClick(int position) {
                // Handle double click if needed
            }
        });

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                // Access the EditText within the SearchView
                EditText searchEditText = etSearch.findViewById(androidx.appcompat.R.id.search_src_text);
                searchEditText.setText(result.get(0));

                textToSpeech = new TextToSpeech(getActivity(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        textToSpeech.setLanguage(Locale.ENGLISH);
                        textToSpeech.speak(result.get(0), TextToSpeech.QUEUE_FLUSH, null, null);
                    }
                });
            }
        }
    }

    private class MyListAdapter extends ArrayAdapter<String> {
        private final Activity context;
        private final String[] name;
        private final Integer[] img;

        public MyListAdapter(Activity context, String[] name, Integer[] img) {
            super(context, R.layout.customlist, name);
            this.context = context;
            this.name = name;
            this.img = img;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View rowview = inflater.inflate(R.layout.customlist, null, true);

            TextView title = rowview.findViewById(R.id.title);
            ImageView imgs = rowview.findViewById(R.id.icon);

            title.setText(name[position]);
            imgs.setImageResource(img[position]);

            return rowview;
        }
    }
}
